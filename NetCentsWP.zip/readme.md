Installing NetCents Wordpress Plugin

1. Clone repsitory and upload to zip file to wordpress plugin section

2. You must have woocommerce installed in order to use NetCents gateway

3. After activating the plugin browse to WooCommerce -> Settings -> Checkout

4. Just under where you clicked Checkout you will see a list of gateways

5. Select either NetCents API or Widget and check enable

6. With your `API key` & `Secret key` generated on our platform input them into appropriate fields

Now when at checkout you will see NetCents or NetCents widget

If you aren't sign up for a Merchant account already you can sign up at : http://merchant.net-cents.com
